﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("PVSMediaPlayerHowTo")>
<Assembly: AssemblyDescription("PVS.MediaPlayer Sample Application")>
<Assembly: AssemblyCompany("PVS The Netherlands")>
<Assembly: AssemblyProduct("PVSMediaPlayerHowTo")>
<Assembly: AssemblyCopyright("© 2021 PVS The Netherlands")>
<Assembly: AssemblyTrademark("PVS The Netherlands")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("561e1177-0bcc-452d-accb-88c66e91b32e")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.4.0.40")>
<Assembly: AssemblyFileVersion("1.4.0.40")>
